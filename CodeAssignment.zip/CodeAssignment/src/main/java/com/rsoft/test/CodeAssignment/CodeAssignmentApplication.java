package com.rsoft.test.CodeAssignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodeAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodeAssignmentApplication.class, args);
	}

}
